return function(page, offset, screen_width, screen_height)

	local percent = math.abs(offset/page.layer.width)
	page.alpha = 1 - percent

    	for i, icon in subviews(page) do
        		icon.alpha = page.alpha
    	end

	local percent = offset/page.width
	page.layer.x = page.layer.x + offset

	local angle = percent*math.pi
	local x = page.width/2
	if percent > 0 then x = -x end

	page:translate(x, 0, 0)
	page:rotate(angle, 0, 1, 0)
	page:translate(-x, 0, 0)
	page:translate(-offset)

	local fade = dofile("include/fade.lua")
	local stay = dofile("include/stay.lua")

	local percent = offset/page.width
	
	stay(page,offset)
	fade(page,percent)

	local direction = 1 
	local lastY = 0

	for i, icon in subviews(page) do
		if (lastY < icon.y) then 
			direction=-direction
			lastY = icon.y
		end
		icon:translate(direction*offset, 0, 0)
    	end	
end
