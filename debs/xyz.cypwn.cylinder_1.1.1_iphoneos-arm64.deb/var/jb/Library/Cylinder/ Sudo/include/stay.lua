return function (page, offset)
    page:translate(offset, 0, 0)
end