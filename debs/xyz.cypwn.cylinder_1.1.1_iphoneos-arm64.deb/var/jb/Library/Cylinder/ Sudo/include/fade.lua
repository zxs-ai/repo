return function (view, percent)
    view.alpha = 1 - math.abs(percent)
end
